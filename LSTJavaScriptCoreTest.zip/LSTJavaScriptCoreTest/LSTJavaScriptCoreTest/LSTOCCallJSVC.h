//
//  LSTOCCallJSVC.h
//  LSTJavaScriptCoreTest
//
//  Created by 兰科 on 2018/5/8.
//  Copyright © 2018年 兰科guagua. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <JavaScriptCore/JavaScriptCore.h>

@interface LSTOCCallJSVC : UIViewController

@property (strong, nonatomic) JSContext * context;

@end
